#ifndef HYBRIS_GLIBC_COMPAT_H
#define HYBRIS_GLIBC_COMPAT_H

#define __INTRODUCED_IN(api)
#define __INTRODUCED_IN_NO_GUARD_FOR_NDK(api)
#define __DEPRECATED_IN(api)
#define __REMOVED_IN(api)
#define __INTRODUCED_IN_32(api)
#define __INTRODUCED_IN_64(api)
#define __INTRODUCED_IN_ARM(api)
#define __INTRODUCED_IN_X86(api)
#define __BIONIC_AVAILABILITY(...)
#define __VERSIONER_NO_GUARD
#define __VERSIONER_FORTIFY_INLINE

#ifndef _Nullable
#define _Nullable
#endif
#ifndef _Nonnull
#define _Nonnull
#endif
#ifndef _Null_unspecified
#define _Null_unspecified
#endif

#endif